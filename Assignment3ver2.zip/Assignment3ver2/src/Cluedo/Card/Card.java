package Cluedo.Card;

public interface Card {
	
}
